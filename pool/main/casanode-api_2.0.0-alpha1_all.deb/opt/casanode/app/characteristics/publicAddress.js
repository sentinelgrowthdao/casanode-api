import { createRequire } from 'module';
import { Logger } from '../utils/logger.js';
import nodeManager from '../utils/node.js';
import { walletLoadAddresses } from '../utils/node.js';
export class PublicAddressCharacteristic {
    /**
     * Bleno instance
     * @type any
     */
    Bleno = undefined;
    /**
     * UUID of the characteristic
     * @type string
     */
    characteristicUuid = '';
    /**
     * Create a new instance of Characteristic
     */
    constructor(uuid) {
        const require = createRequire(import.meta.url);
        this.Bleno = require('bleno');
        this.characteristicUuid = uuid;
    }
    /**
     * Create a new instance of PublicAddressCharacteristic
     */
    create() {
        if (this.Bleno === undefined)
            return null;
        return new this.Bleno.Characteristic({
            uuid: this.characteristicUuid,
            properties: ['read'],
            onReadRequest: this.onReadRequest.bind(this),
        });
    }
    /**
     * Called when the characteristic is read
     * @param offset number
     * @param callback (result: number, data: Buffer) => void
     * @returns void
     */
    onReadRequest(offset, callback) {
        // Get the value from the configuration
        const address = nodeManager.getConfig().walletPublicAddress;
        // If address is empty
        if (address === '') {
            // If the passphrase is unavailable
            if (!nodeManager.passphraseAvailable()) {
                callback(this.Bleno.Characteristic.RESULT_UNLIKELY_ERROR, Buffer.from(''));
                return true;
            }
            // Get the wallet passphrase stored in the configuration
            const passphrase = nodeManager.getConfig().walletPassphrase;
            // Load wallet informations
            walletLoadAddresses(passphrase).then(() => {
                // Get the value from the configuration
                const address = nodeManager.getConfig().walletPublicAddress;
                // Return the value to the subscriber
                callback(this.Bleno.Characteristic.RESULT_SUCCESS, Buffer.from(address));
                return null;
            })
                .catch((error) => {
                Logger.error(`Error while loading the wallet addresses: ${error}`);
                callback(this.Bleno.Characteristic.RESULT_UNLIKELY_ERROR, Buffer.from(''));
                return null;
            });
        }
        else {
            // Return the value to the subscriber
            callback(this.Bleno.Characteristic.RESULT_SUCCESS, Buffer.from(address));
        }
    }
}
