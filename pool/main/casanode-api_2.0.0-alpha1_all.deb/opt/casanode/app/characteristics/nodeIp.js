import { createRequire } from 'module';
import { Logger } from '../utils/logger.js';
import nodeManager from '../utils/node.js';
import { isValidIP, isValidDns } from '../utils/validators.js';
export class NodeIpCharacteristic {
    /**
     * Bleno instance
     * @type any
     */
    Bleno = undefined;
    /**
     * UUID of the characteristic
     * @type string
     */
    characteristicUuid = '';
    /**
     * Create a new instance of Characteristic
     */
    constructor(uuid) {
        const require = createRequire(import.meta.url);
        this.Bleno = require('bleno');
        this.characteristicUuid = uuid;
    }
    /**
     * Create a new instance of NodeIpCharacteristic
     */
    create() {
        if (this.Bleno === undefined)
            return null;
        return new this.Bleno.Characteristic({
            uuid: this.characteristicUuid,
            properties: ['read', 'write'],
            onReadRequest: this.onReadRequest.bind(this),
            onWriteRequest: this.onWriteRequest.bind(this),
        });
    }
    /**
     * Called when the characteristic is read
     * @param offset number
     * @param callback (result: number, data: Buffer) => void
     * @returns void
     */
    onReadRequest(offset, callback) {
        // Get the value from the configuration
        const value = nodeManager.getConfig().node_ip;
        // Return the value to the subscriber
        callback(this.Bleno.Characteristic.RESULT_SUCCESS, Buffer.from(value));
    }
    /**
     * Called when the characteristic is written
     * @param data Buffer
     * @param offset number
     * @param withoutResponse boolean
     * @param callback (result: number) => void
     * @returns void
     */
    onWriteRequest(data, offset, withoutResponse, callback) {
        // Get the value from the buffer
        const value = data.toString('utf-8').trim();
        // Check if the value is a valid IP
        if (isValidIP(value)) {
            // Set the value in the configuration immediately
            nodeManager.setNodeIp(value);
            // Notify the subscriber of success
            callback(this.Bleno.Characteristic.RESULT_SUCCESS);
            Logger.info(`Parameter "node_ip" updated via Bluetooth to: ${value}`);
        }
        else {
            // Check if the value is a valid DNS asynchronously
            isValidDns(value).then((isValid) => {
                if (isValid) {
                    // If valid DNS, set the value in the configuration
                    nodeManager.setNodeIp(value);
                    // Notify the subscriber of success
                    callback(this.Bleno.Characteristic.RESULT_SUCCESS);
                    Logger.info(`Parameter "node_ip" updated via Bluetooth to: ${value}`);
                    return null;
                }
                else {
                    // If invalid, return an error
                    Logger.error('Invalid value received via Bluetooth for "node_ip".');
                    callback(this.Bleno.Characteristic.RESULT_UNLIKELY_ERROR);
                    return null;
                }
            })
                .catch((error) => {
                // Handle any errors that occur during DNS resolution
                Logger.error(`Error while resolving DNS: ${error}`);
                callback(this.Bleno.Characteristic.RESULT_UNLIKELY_ERROR);
            });
        }
    }
}
