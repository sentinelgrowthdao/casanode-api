import { checkImageAvailability, containerExists, containerRunning, } from '../utils/docker.js';
import { nodeConfig, isNodeConfigFileAvailable, isWireguardConfigFileAvailable, isV2RayConfigFileAvailable, isCertificateKeyAvailable, isWalletAvailable, } from '../utils/node.js';
;
export const checkInstallation = async () => {
    // Get the node configuration
    const config = nodeConfig();
    // Return the installation check
    return {
        image: await checkImageAvailability(),
        containerExists: await containerExists(),
        containerRunning: await containerRunning(),
        nodeConfig: isNodeConfigFileAvailable(),
        vpnConfig: config.vpn_type === 'wireguard' ? isWireguardConfigFileAvailable() : isV2RayConfigFileAvailable(),
        certificateKey: isCertificateKeyAvailable(),
        wallet: await isWalletAvailable(),
    };
};
