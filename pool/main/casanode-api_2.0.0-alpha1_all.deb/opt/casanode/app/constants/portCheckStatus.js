/**
 * Enum for the status of a port check.
 */
export var PortCheckStatus;
(function (PortCheckStatus) {
    PortCheckStatus[PortCheckStatus["NOT_STARTED"] = 0] = "NOT_STARTED";
    PortCheckStatus[PortCheckStatus["IN_PROGRESS"] = 1] = "IN_PROGRESS";
    PortCheckStatus[PortCheckStatus["OPEN"] = 2] = "OPEN";
    PortCheckStatus[PortCheckStatus["CLOSED"] = 3] = "CLOSED";
    PortCheckStatus[PortCheckStatus["ERROR"] = -1] = "ERROR";
})(PortCheckStatus || (PortCheckStatus = {}));
