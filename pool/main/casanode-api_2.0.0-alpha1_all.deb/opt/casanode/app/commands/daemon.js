import { Logger } from '../utils/logger.js';
import WebServer from '../utils/web.js';
import { loadingNodeInformations, loadingSystemInformations } from '../actions/startup.js';
/**
 * Daemon command
 * @returns void
 */
export const daemonCommand = async () => {
    Logger.info('Daemon process started.');
    try {
        // Load system information
        await loadingSystemInformations();
        // Load node information
        await loadingNodeInformations();
        // Start the web server
        await startWebServer();
    }
    catch (error) {
        Logger.error('An unexpected error occurred in daemon process.', error);
    }
};
/**
 * Start the web server
 * @returns void
 */
const startWebServer = async () => {
    try {
        Logger.info('Starting web server...');
        // Get the web server instance
        const webServer = WebServer.getInstance();
        // Initialize SSL and routes
        await webServer.init();
        // Start the web server
        webServer.start();
        Logger.info('Web server started successfully.');
    }
    catch (error) {
        Logger.error('Failed to start the web server.', error);
    }
};
