import jwt from 'jsonwebtoken';
import config from '../utils/configuration.js';
import { Logger } from '../utils/logger.js';
const ONE_YEAR = '365d';
/**
 * POST /api/v1/auth/login
 * Accepts a pre-shared token and returns a JWT (1 year)
 */
export async function login(req, res) {
    try {
        const { token } = req.body || {};
        if (!token || typeof token !== 'string') {
            res.status(400).json({ error: 'Missing token' });
            return;
        }
        if (token !== config.API_AUTH) {
            res.status(403).json({ error: 'Invalid token' });
            return;
        }
        const payload = { sub: config.DEVICE_ID };
        const signed = jwt.sign(payload, config.JWT_SECRET, { expiresIn: ONE_YEAR });
        const decoded = jwt.decode(signed);
        const exp = decoded?.exp ? decoded.exp : undefined;
        res.json({
            jwt: signed,
            expiresAt: exp ? exp * 1000 : undefined,
        });
    }
    catch (err) {
        Logger.error('Login error: ' + err);
        res.status(500).json({ error: 'Login failed' });
    }
}
/**
 * POST /api/v1/auth/refresh
 * Requires a valid JWT; returns a fresh JWT (1 year)
 */
export async function refresh(req, res) {
    try {
        // `authenticateToken` attaches the decoded JWT if needed
        const current = req.jwt;
        const sub = current?.sub || config.DEVICE_ID;
        const signed = jwt.sign({ sub }, config.JWT_SECRET, { expiresIn: ONE_YEAR });
        const decoded = jwt.decode(signed);
        const exp = decoded?.exp ? decoded.exp : undefined;
        res.json({
            jwt: signed,
            expiresAt: exp ? exp * 1000 : undefined,
        });
    }
    catch (err) {
        Logger.error('Token refresh error: ' + err);
        res.status(500).json({ error: 'Refresh failed' });
    }
}
