import { createRequire } from 'module';
import { Logger } from '../utils/logger.js';
import { imagePull } from '../utils/docker.js';
var InstallStatus;
(function (InstallStatus) {
    InstallStatus[InstallStatus["NOT_STARTED"] = 0] = "NOT_STARTED";
    InstallStatus[InstallStatus["IN_PROGRESS"] = 1] = "IN_PROGRESS";
    InstallStatus[InstallStatus["COMPLETED"] = 2] = "COMPLETED";
    InstallStatus[InstallStatus["ERROR"] = -1] = "ERROR";
})(InstallStatus || (InstallStatus = {}));
export class InstallDockerImageCharacteristic {
    /**
     * Bleno instance
     * @type any
     */
    Bleno = undefined;
    /**
     * UUID of the characteristic
     * @type string
     */
    characteristicUuid = '';
    /**
     * Installation status
     * @type InstallStatus
     */
    installStatus = InstallStatus.NOT_STARTED;
    /**
     * Create a new instance of Characteristic
     */
    constructor(uuid) {
        const require = createRequire(import.meta.url);
        this.Bleno = require('bleno');
        this.characteristicUuid = uuid;
    }
    /**
     * Create a new instance of InstallDockerImageCharacteristic
     */
    create() {
        if (this.Bleno === undefined)
            return null;
        return new this.Bleno.Characteristic({
            uuid: this.characteristicUuid,
            properties: ['read', 'write'],
            onReadRequest: this.onReadRequest.bind(this),
            onWriteRequest: this.onWriteRequest.bind(this),
        });
    }
    /**
     * Called when the characteristic is read
     * @param offset number
     * @param callback (result: number, data: Buffer) => void
     * @returns void
     */
    onReadRequest(offset, callback) {
        let response;
        switch (this.installStatus) {
            case InstallStatus.NOT_STARTED:
                response = '0';
                break;
            case InstallStatus.IN_PROGRESS:
                response = '1';
                break;
            case InstallStatus.COMPLETED:
                response = '2';
                break;
            case InstallStatus.ERROR:
                response = '-1';
                break;
        }
        Logger.info(`Install Docker Image status: ${response}`);
        callback(this.Bleno.Characteristic.RESULT_SUCCESS, Buffer.from(response));
    }
    // Start the installation process with a write request
    onWriteRequest(data, offset, withoutResponse, callback) {
        if (this.installStatus === InstallStatus.IN_PROGRESS) {
            Logger.error('Installation already in progress');
            callback(this.Bleno.Characteristic.RESULT_UNLIKELY_ERROR);
            return;
        }
        // Start the installation process
        this.installStatus = InstallStatus.IN_PROGRESS;
        // Send a response to the client
        callback(this.Bleno.Characteristic.RESULT_SUCCESS);
        Logger.info('Starting Docker image installation');
        // Start the installation process
        imagePull()
            .then((status) => {
            Logger.info(`Docker installation status: ${status}`);
            this.installStatus = status ? InstallStatus.COMPLETED : InstallStatus.ERROR;
            return null;
        })
            .catch((error) => {
            Logger.error(`Error while installing Docker image: ${error}`);
            this.installStatus = InstallStatus.ERROR;
            return null;
        });
    }
}
