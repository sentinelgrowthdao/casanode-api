import * as fs from 'fs';
import * as net from 'net';
import config from './configuration.js';
import { Logger } from './logger.js';
class UpnpManager {
    static instance;
    runtimeDisabled = false;
    constructor() {
    }
    /**
     * Get singleton instance
     * @returns UpnpManager
     */
    static getInstance() {
        if (!UpnpManager.instance)
            UpnpManager.instance = new UpnpManager();
        return UpnpManager.instance;
    }
    /**
     * Synchronize desired mappings with the local daemon
     * @param portConfig UpnpPortConfig
     * @returns Promise<boolean>
     */
    async syncConfiguredMappings(portConfig) {
        if (!this.isEnabled())
            return true;
        if (!await this.ensureServiceAvailable())
            return false;
        const mappings = this.buildMappings(portConfig);
        const response = await this.sendCommand({
            action: 'sync',
            mappings,
        });
        if (!response?.ok) {
            Logger.error(`UPnP sync failed: ${response?.error || 'invalid response from daemon'}`);
            return false;
        }
        Logger.info(`UPnP mappings synchronized (${mappings.length} desired mapping(s)).`);
        return true;
    }
    /**
     * Clear all desired mappings from the local daemon
     * @returns Promise<boolean>
     */
    async clearMappings() {
        if (!this.isEnabled())
            return true;
        if (!await this.ensureServiceAvailable())
            return false;
        const response = await this.sendCommand({
            action: 'clear',
        });
        if (!response?.ok) {
            Logger.error(`UPnP clear failed: ${response?.error || 'invalid response from daemon'}`);
            return false;
        }
        Logger.info('UPnP mappings cleared.');
        return true;
    }
    /**
     * Fetch daemon status
     * @returns Promise<UpnpResponse | null>
     */
    async status() {
        if (!this.isEnabled())
            return null;
        if (!await this.ensureServiceAvailable())
            return null;
        return this.sendCommand({
            action: 'status',
        });
    }
    /**
     * Force an immediate daemon refresh
     * @returns Promise<boolean>
     */
    async refresh() {
        if (!this.isEnabled())
            return true;
        if (!await this.ensureServiceAvailable())
            return false;
        const response = await this.sendCommand({
            action: 'refresh',
        });
        return response?.ok === true;
    }
    /**
     * Ping the daemon
     * @returns Promise<boolean>
     */
    async ping() {
        if (!this.isEnabled())
            return false;
        const response = await this.sendCommand({
            action: 'ping',
        });
        return response?.ok === true;
    }
    /**
     * Determine if the feature is enabled in configuration
     * @returns boolean
     */
    isEnabled() {
        const raw = config.UPNP_ENABLED;
        if (typeof raw === 'boolean')
            return raw;
        const normalized = String(raw || '').trim().toLowerCase();
        return ['1', 'true', 'yes', 'on'].includes(normalized);
    }
    /**
     * Determine whether the configured daemon is reachable
     * @returns Promise<boolean>
     */
    async ensureServiceAvailable() {
        if (this.runtimeDisabled)
            return false;
        const socketPath = this.getSocketPath();
        if (!fs.existsSync(socketPath)) {
            this.disableRuntime(`UPnP socket not found at ${socketPath}. Feature disabled until process restart.`);
            return false;
        }
        const alive = await this.ping();
        if (!alive) {
            this.disableRuntime(`UPnP daemon did not respond on ${socketPath}. Feature disabled until process restart.`);
            return false;
        }
        return true;
    }
    /**
     * Prevent repeated failing attempts when the daemon is not available
     * @param message string
     * @returns void
     */
    disableRuntime(message) {
        this.runtimeDisabled = true;
        Logger.info(message);
    }
    /**
     * Build desired UPnP mappings from node configuration
     * @param portConfig UpnpPortConfig
     * @returns UpnpMapping[]
     */
    buildMappings(portConfig) {
        const mappings = [];
        const leaseSeconds = this.getLeaseSeconds();
        const internalClient = this.getInternalClient();
        if (this.isValidPort(portConfig.node_port)) {
            mappings.push({
                id: 'casanode-node',
                protocol: 'TCP',
                external_port: portConfig.node_port,
                internal_port: portConfig.node_port,
                internal_client: internalClient,
                lease_seconds: leaseSeconds,
                description: config.UPNP_NODE_DESCRIPTION || 'Casanode node',
                enabled: true,
            });
        }
        const vpnProtocol = this.resolveVpnProtocol(portConfig.vpn_type, portConfig.vpn_protocol);
        if (vpnProtocol && this.isValidPort(portConfig.vpn_port)) {
            mappings.push({
                id: 'casanode-vpn',
                protocol: vpnProtocol,
                external_port: portConfig.vpn_port,
                internal_port: portConfig.vpn_port,
                internal_client: internalClient,
                lease_seconds: leaseSeconds,
                description: config.UPNP_VPN_DESCRIPTION || 'Casanode VPN',
                enabled: true,
            });
        }
        return mappings.map((mapping) => {
            if (!mapping.internal_client)
                delete mapping.internal_client;
            return mapping;
        });
    }
    /**
     * Resolve VPN protocol from node configuration
     * @param vpnType string | undefined
     * @param vpnProtocol string | undefined
     * @returns 'TCP' | 'UDP' | null
     */
    resolveVpnProtocol(vpnType, vpnProtocol) {
        if (!vpnType)
            return null;
        if (vpnType === 'wireguard')
            return 'UDP';
        if (vpnType === 'v2ray')
            return 'TCP';
        if (vpnType === 'openvpn') {
            const normalized = (vpnProtocol || 'udp').trim().toLowerCase();
            if (normalized === 'tcp')
                return 'TCP';
            return 'UDP';
        }
        Logger.error(`Unsupported VPN type for UPnP mapping: ${vpnType}`);
        return null;
    }
    /**
     * Validate port number
     * @param port number | undefined
     * @returns boolean
     */
    isValidPort(port) {
        return typeof port === 'number' && Number.isInteger(port) && port >= 1 && port <= 65535;
    }
    /**
     * Read socket path from configuration
     * @returns string
     */
    getSocketPath() {
        return String(config.UPNP_CONTROL_SOCKET || '/run/casanode-natd/control.sock');
    }
    /**
     * Read lease duration from configuration
     * @returns number
     */
    getLeaseSeconds() {
        const value = parseInt(String(config.UPNP_LEASE_SECONDS || '3600'), 10);
        return Number.isFinite(value) && value > 0 ? value : 3600;
    }
    /**
     * Read optional internal client address from configuration
     * @returns string | undefined
     */
    getInternalClient() {
        const internalClient = String(config.UPNP_INTERNAL_CLIENT || '').trim();
        return internalClient.length > 0 ? internalClient : undefined;
    }
    /**
     * Send a command to the UPnP daemon
     * @param request UpnpRequest
     * @returns Promise<UpnpResponse | null>
     */
    async sendCommand(request) {
        const socketPath = this.getSocketPath();
        return new Promise((resolve) => {
            let settled = false;
            let buffer = '';
            const finish = (value) => {
                if (settled)
                    return;
                settled = true;
                resolve(value);
            };
            const socket = net.createConnection(socketPath);
            socket.setEncoding('utf8');
            socket.setTimeout(5000);
            socket.on('connect', () => {
                socket.write(`${JSON.stringify(request)}\n`);
            });
            socket.on('data', (chunk) => {
                buffer += chunk;
                if (!buffer.includes('\n'))
                    return;
                const line = buffer.split('\n')[0].trim();
                socket.end();
                if (!line) {
                    finish(null);
                    return;
                }
                try {
                    finish(JSON.parse(line));
                }
                catch (error) {
                    Logger.error(`Failed to parse UPnP daemon response: ${String(error)}`);
                    finish(null);
                }
            });
            socket.on('timeout', () => {
                Logger.error(`UPnP daemon request timed out on ${socketPath}`);
                socket.destroy();
                finish(null);
            });
            socket.on('error', (error) => {
                Logger.error(`UPnP daemon communication failed: ${error.message}`);
                finish(null);
            });
            socket.on('end', () => {
                if (!settled) {
                    const line = buffer.trim();
                    if (!line) {
                        finish(null);
                        return;
                    }
                    try {
                        finish(JSON.parse(line));
                    }
                    catch (error) {
                        Logger.error(`Failed to parse UPnP daemon response: ${String(error)}`);
                        finish(null);
                    }
                }
            });
        });
    }
}
const upnpManager = UpnpManager.getInstance();
export default upnpManager;
export const clearUpnpMappings = () => upnpManager.clearMappings();
export const getUpnpStatus = () => upnpManager.status();
export const refreshUpnpMappings = () => upnpManager.refresh();
export const syncConfiguredUpnpMappings = (portConfig) => upnpManager.syncConfiguredMappings(portConfig);
