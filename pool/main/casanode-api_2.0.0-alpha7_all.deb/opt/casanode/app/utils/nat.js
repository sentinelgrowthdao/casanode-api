import * as fs from 'fs';
import * as net from 'net';
import config from './configuration.js';
import { Logger } from './logger.js';
class NatManager {
    static instance;
    constructor() {
    }
    static getInstance() {
        if (!NatManager.instance)
            NatManager.instance = new NatManager();
        return NatManager.instance;
    }
    async syncConfiguredMappings(portConfig) {
        if (!this.isEnabled())
            return true;
        if (!await this.ensureServiceAvailable())
            return false;
        const mappings = this.buildMappings(portConfig);
        const response = await this.sendCommand({
            action: 'sync',
            mappings,
        });
        if (!response?.ok) {
            Logger.error(`NAT sync failed: ${response?.error || 'invalid response from daemon'}`);
            return false;
        }
        Logger.info(`NAT mappings synchronized (${mappings.length} desired mapping(s)).`);
        return true;
    }
    async clearMappings() {
        if (!this.isEnabled())
            return true;
        if (!await this.ensureServiceAvailable())
            return false;
        const response = await this.sendCommand({
            action: 'clear',
        });
        if (!response?.ok) {
            Logger.error(`NAT clear failed: ${response?.error || 'invalid response from daemon'}`);
            return false;
        }
        Logger.info('NAT mappings cleared.');
        return true;
    }
    async status() {
        if (!this.isEnabled())
            return null;
        if (!await this.ensureServiceAvailable())
            return null;
        return this.sendCommand({
            action: 'status',
        });
    }
    async refresh() {
        if (!this.isEnabled())
            return true;
        if (!await this.ensureServiceAvailable())
            return false;
        const response = await this.sendCommand({
            action: 'refresh',
        });
        return response?.ok === true;
    }
    async ping() {
        if (!this.isEnabled())
            return false;
        const response = await this.sendCommand({
            action: 'ping',
        });
        return response?.ok === true;
    }
    isEnabled() {
        const raw = config.UPNP_ENABLED;
        if (typeof raw === 'boolean')
            return raw;
        const normalized = String(raw || '').trim().toLowerCase();
        return ['1', 'true', 'yes', 'on'].includes(normalized);
    }
    async ensureServiceAvailable() {
        const socketPath = this.getSocketPath();
        if (!fs.existsSync(socketPath)) {
            Logger.info(`NAT socket not found at ${socketPath}. Will retry on the next request.`);
            return false;
        }
        return true;
    }
    buildMappings(portConfig) {
        const mappings = [];
        const leaseSeconds = this.getLeaseSeconds();
        const internalClient = this.getInternalClient();
        if (this.isValidPort(portConfig.node_port)) {
            mappings.push({
                id: 'casanode-node',
                protocol: 'TCP',
                external_port: portConfig.node_port,
                internal_port: portConfig.node_port,
                internal_client: internalClient,
                lease_seconds: leaseSeconds,
                description: config.UPNP_NODE_DESCRIPTION || 'Casanode node',
                enabled: true,
            });
        }
        const vpnProtocol = this.resolveVpnProtocol(portConfig.vpn_type, portConfig.vpn_protocol);
        if (vpnProtocol && this.isValidPort(portConfig.vpn_port)) {
            mappings.push({
                id: 'casanode-vpn',
                protocol: vpnProtocol,
                external_port: portConfig.vpn_port,
                internal_port: portConfig.vpn_port,
                internal_client: internalClient,
                lease_seconds: leaseSeconds,
                description: config.UPNP_VPN_DESCRIPTION || 'Casanode VPN',
                enabled: true,
            });
        }
        return mappings.map((mapping) => {
            if (!mapping.internal_client)
                delete mapping.internal_client;
            return mapping;
        });
    }
    resolveVpnProtocol(vpnType, vpnProtocol) {
        if (!vpnType)
            return null;
        if (vpnType === 'wireguard')
            return 'UDP';
        if (vpnType === 'v2ray')
            return 'TCP';
        if (vpnType === 'openvpn') {
            const normalized = (vpnProtocol || 'udp').trim().toLowerCase();
            if (normalized === 'tcp')
                return 'TCP';
            return 'UDP';
        }
        Logger.error(`Unsupported VPN type for NAT mapping: ${vpnType}`);
        return null;
    }
    isValidPort(port) {
        return typeof port === 'number' && Number.isInteger(port) && port >= 1 && port <= 65535;
    }
    getSocketPath() {
        return String(config.UPNP_CONTROL_SOCKET || '/run/casanode-natd/control.sock');
    }
    getLeaseSeconds() {
        const value = parseInt(String(config.UPNP_LEASE_SECONDS || '3600'), 10);
        return Number.isFinite(value) && value > 0 ? value : 3600;
    }
    getInternalClient() {
        const internalClient = String(config.UPNP_INTERNAL_CLIENT || '').trim();
        return internalClient.length > 0 ? internalClient : undefined;
    }
    async sendCommand(request) {
        return this.sendCommandWithRetry(request);
    }
    async sendCommandWithRetry(request) {
        const firstAttempt = await this.sendCommandOnce(request);
        if (firstAttempt !== null)
            return firstAttempt;
        await new Promise((resolve) => setTimeout(resolve, 250));
        return this.sendCommandOnce(request);
    }
    async sendCommandOnce(request) {
        const socketPath = this.getSocketPath();
        return new Promise((resolve) => {
            let settled = false;
            let buffer = '';
            const finish = (value) => {
                if (settled)
                    return;
                settled = true;
                resolve(value);
            };
            const socket = net.createConnection(socketPath);
            socket.setEncoding('utf8');
            socket.setTimeout(5000);
            socket.on('connect', () => {
                socket.write(`${JSON.stringify(request)}\n`);
            });
            socket.on('data', (chunk) => {
                buffer += chunk;
                if (!buffer.includes('\n'))
                    return;
                const line = buffer.split('\n')[0].trim();
                socket.end();
                if (!line) {
                    finish(null);
                    return;
                }
                try {
                    finish(JSON.parse(line));
                }
                catch (error) {
                    Logger.error(`Failed to parse NAT daemon response: ${String(error)}`);
                    finish(null);
                }
            });
            socket.on('timeout', () => {
                Logger.error(`NAT daemon request timed out on ${socketPath}`);
                socket.destroy();
                finish(null);
            });
            socket.on('error', (error) => {
                Logger.error(`NAT daemon communication failed: ${error.message}`);
                finish(null);
            });
            socket.on('end', () => {
                if (!settled) {
                    const line = buffer.trim();
                    if (!line) {
                        finish(null);
                        return;
                    }
                    try {
                        finish(JSON.parse(line));
                    }
                    catch (error) {
                        Logger.error(`Failed to parse NAT daemon response: ${String(error)}`);
                        finish(null);
                    }
                }
            });
        });
    }
}
const natManager = NatManager.getInstance();
export default natManager;
export const clearNatMappings = () => natManager.clearMappings();
export const getNatStatus = () => natManager.status();
export const refreshNatMappings = () => natManager.refresh();
export const syncConfiguredNatMappings = (portConfig) => natManager.syncConfiguredMappings(portConfig);
