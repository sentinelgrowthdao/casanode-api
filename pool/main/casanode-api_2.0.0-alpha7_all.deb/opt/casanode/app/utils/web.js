import express from 'express';
import http from 'http';
import cors from 'cors';
import { Logger } from './logger.js';
import config from './configuration.js';
import apiRouter from '../web/apiRoutes.js';
class WebServer {
    static instance;
    app = express();
    apiHostname = '0.0.0.0';
    apiPort = 8081;
    constructor() {
        // If the API_LISTEN configuration is set
        if (config.API_LISTEN && config.API_LISTEN.includes(':')) {
            // Set the port and hostname from the configuration
            this.apiHostname = config.API_LISTEN.split(':')[0] || '0.0.0.0';
            this.apiPort = parseInt(config.API_LISTEN.split(':')[1]) || 8081;
        }
    }
    /**
     * Get instance of WebServer
     * @returns WebServer
     */
    static getInstance() {
        if (!WebServer.instance) {
            WebServer.instance = new WebServer();
        }
        return WebServer.instance;
    }
    /**
     * Initialize the API server and routes
     */
    async init() {
        // Setup routes
        this.setupRoutes();
    }
    /**
     * Setup routes for HTTP and HTTPS
     * @returns void
     */
    setupRoutes() {
        // Enable CORS for all routes
        this.app.use(cors({
            origin: true, // Allow all origins
            methods: 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS',
            allowedHeaders: 'Content-Type, Authorization, X-Requested-With, Accept, Origin',
            credentials: true,
            optionsSuccessStatus: 200, // Some legacy browsers choke on 204
        }));
        // Handle preflight requests for every route
        this.app.options(/.*/, cors());
        // Add the JSON parsing middleware
        this.app.use(express.json());
        // Add the API routes
        this.app.use('/api/v1', apiRouter);
    }
    /**
     * Start the API server (HTTP only)
     * @returns void
     */
    start() {
        const server = http.createServer(this.app);
        server.on('error', (error) => {
            Logger.error(`API server failed to bind on ${this.apiHostname}:${this.apiPort}`, error);
        });
        server.listen(this.apiPort, this.apiHostname, () => {
            Logger.info(`API server running at http://${this.apiHostname}:${this.apiPort}`);
        });
    }
}
export default WebServer;
