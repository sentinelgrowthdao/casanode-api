import * as fs from 'fs';
import * as dotenv from 'dotenv';
import * as path from 'path';
import * as os from 'os';
import axios from 'axios';
import { v4 as uuidv4 } from 'uuid';
import { Logger } from './logger.js';
class ConfigurationLoader {
    static instance;
    configFile = '/etc/casanode.conf';
    config;
    // Default configuration
    defaultConfig = {
        CASANODE_VERSION: 'alpha',
        DOCKER_IMAGE_NAME: 'ghcr.io/sentinel-official/sentinel-dvpnx:latest',
        DOCKER_CONTAINER_NAME: 'sentinel-dvpnx',
        CONTAINER_DATA_DIR: '/root/.sentinel-dvpnx',
        CONFIG_DIR: process.env.HOME ? path.join(process.env.HOME, '.sentinel-dvpnx') : '/opt/casanode/.sentinel-dvpnx',
        LOG_DIR: '/var/log/casanode',
        DOCKER_SOCKET: this.getDockerDefaultSocketPath(),
        DEVICE_ID: uuidv4(),
        API_LISTEN: '0.0.0.0:14045',
        API_AUTH: this.generateAuthToken(),
        JWT_SECRET: this.generateJwtSecret(),
        API_BALANCE: [
            'https://api-sentinel.busurnode.com/cosmos/bank/v1beta1/balances/',
            'https://api.sentinel.quokkastake.io/cosmos/bank/v1beta1/balances/',
            'https://wapi.foxinodes.net/api/v1/sentinel/address/'
        ],
        FOXINODES_API_CHECK_IP: 'https://wapi.foxinodes.net/api/v1/sentinel/check-ip',
        FOXINODES_API_DVPN_CONFIG: 'https://wapi.foxinodes.net/api/v1/sentinel/dvpn-node/configuration',
        FOXINODES_API_CHECK_PORT: 'https://wapi.foxinodes.net/api/v1/sentinel/dvpn-node/check-port/',
        UPNP_ENABLED: 'true',
        UPNP_CONTROL_SOCKET: '/run/casanode-natd/control.sock',
        UPNP_LEASE_SECONDS: '3600',
        UPNP_INTERNAL_CLIENT: '',
        UPNP_NODE_DESCRIPTION: 'Casanode node',
        UPNP_VPN_DESCRIPTION: 'Casanode VPN',
        SENTRY_DSN: '',
    };
    constructor() {
        this.config = this.loadConfig();
        this.saveConfig();
    }
    /**
     * Get instance of ConfigurationLoader
     * @returns ConfigurationLoader
     */
    static getInstance() {
        // Create instance if it does not exist
        if (!ConfigurationLoader.instance)
            ConfigurationLoader.instance = new ConfigurationLoader();
        // Return instance
        return ConfigurationLoader.instance;
    }
    /**
     * Get current configuration
     * @returns AppConfigData
     */
    getConfig() {
        return this.config;
    }
    /**
     * Reset the node configuration
     * @returns void
     */
    resetConfiguration() {
        // Preserve the current API_AUTH so it is never regenerated during a factory reset
        const currentApiAuth = this.config?.API_AUTH;
        this.applyConfig({ ...this.defaultConfig });
        if (currentApiAuth) {
            this.config.API_AUTH = currentApiAuth;
        }
        // Save updated configuration with preserved API_AUTH
        this.saveConfig();
    }
    /**
     * Load configuration from file and merge it with default configuration
     */
    loadConfig() {
        const configFromFile = this.loadConfigFromFile();
        // Merge default and file configurations
        const mergedConfig = { ...this.defaultConfig, ...configFromFile };
        // Filter out undefined values
        const filteredConfig = Object.keys(mergedConfig).reduce((acc, key) => {
            const value = mergedConfig[key];
            if (value !== undefined) {
                acc[key] = value;
            }
            return acc;
        }, {});
        // Save filtered configuration
        return filteredConfig;
    }
    /**
     * Apply a new config object while preserving the exported object reference
     * @param nextConfig AppConfigData
     * @returns void
     */
    applyConfig(nextConfig) {
        if (!this.config) {
            this.config = nextConfig;
            return;
        }
        for (const key of Object.keys(this.config)) {
            if (!(key in nextConfig))
                delete this.config[key];
        }
        Object.assign(this.config, nextConfig);
    }
    /**
     * Load configuration from file
     * @returns Partial<AppConfigData>
     */
    loadConfigFromFile() {
        try {
            if (fs.existsSync(this.configFile)) {
                // Parse configuration file
                const config = dotenv.parse(fs.readFileSync(this.configFile));
                const parsedConfig = {};
                // Manually parse arrays
                for (const key in config) {
                    let value = config[key];
                    // Skip keys with empty values
                    if (!value.trim())
                        continue;
                    // Check if value is an array
                    if (value.startsWith('[') && value.endsWith(']')) {
                        parsedConfig[key] = value
                            .slice(1, -1)
                            .split(',')
                            .map((item) => item.trim());
                    }
                    else {
                        parsedConfig[key] = value;
                    }
                }
                return parsedConfig;
            }
            else {
                console.error(`Configuration file ${this.configFile} does not exist. Using default values.`);
                return {};
            }
        }
        catch (error) {
            console.error(`An error occurred while loading configuration file: ${error}`);
            return {};
        }
    }
    /**
     * Save configuration to file
     * @returns boolean
     */
    saveConfig() {
        try {
            const configData = Object.entries(this.config)
                .map(([key, value]) => {
                if (Array.isArray(value)) {
                    const arrayValues = value.join(',');
                    return `${key}=[${arrayValues}]`;
                }
                else {
                    return `${key}=${value}`;
                }
            })
                .join('\n');
            fs.writeFileSync(this.configFile, configData);
            return true;
        }
        catch (error) {
            console.error(`An error occurred while saving configuration file: ${error}`);
            return false;
        }
    }
    /**
     * Update a configuration value and optionally persist it
     * @param key keyof AppConfigData
     * @param value AppConfigData value
     * @param persist boolean
     * @returns boolean
     */
    setConfigValue(key, value, persist = true) {
        this.config[key] = value;
        if (!persist)
            return true;
        return this.saveConfig();
    }
    /**
     * Get remote address
     * @returns Promise<RemoteAddressData>
     */
    async getRemoteAddress() {
        // Initialize default values
        let nodeIP = '0.0.0.0';
        let nodeIPv6 = '';
        let nodeCountry = 'NA';
        const requests = [];
        // Attempt to get IPv4 address
        requests.push((async () => {
            try {
                const response = await axios.get('https://api.ipify.org?format=json', { timeout: 5000 });
                if (response.status === 200 && response.data.ip)
                    nodeIP = response.data.ip;
            }
            catch (error) {
                Logger.error(`Failed to get IPv4 from ipify: ${error}`);
            }
        })());
        // Attempt to get IPv6 address
        requests.push((async () => {
            try {
                const response = await axios.get('https://api64.ipify.org?format=json', { timeout: 5000 });
                if (response.status === 200 && response.data.ip)
                    nodeIPv6 = response.data.ip;
            }
            catch (error) {
                Logger.error(`Failed to get IPv6 from ipify: ${error}`);
            }
        })());
        await Promise.all(requests);
        try {
            // Attempt to get the IP and country from the primary API
            const response = await axios.get(this.config.FOXINODES_API_CHECK_IP, { timeout: 15000 });
            if (response.status === 200) {
                const data = response.data;
                nodeIP = data.ip || nodeIP;
                nodeIPv6 = data.ip6 || nodeIPv6;
                nodeCountry = data.iso_code || nodeCountry;
            }
            else {
                Logger.error('Failed to fetch IP from primary API.');
            }
        }
        catch (error) {
            Logger.error(`Primary API call failed: ${error}. Trying fallback method.`);
            try {
                // Fallback to checkip.dyndns.org
                const response = await axios.get('http://checkip.dyndns.org/', { timeout: 5000 });
                if (response.status === 200) {
                    const value = response.data;
                    nodeIP = value.split('Current IP Address: ')[1].split('<')[0];
                }
                else {
                    Logger.error('Failed to fetch IP from fallback method.');
                }
            }
            catch (fallbackError) {
                Logger.error(`Fallback method also failed: ${fallbackError}.`);
            }
        }
        // Return IP and country
        return {
            ip: nodeIP,
            ipv6: nodeIPv6 || '',
            country: nodeCountry
        };
    }
    /**
     * Refresh network configuration from the API
     * @returns Promise<boolean>
     */
    async refreshNetworkConfiguration() {
        try {
            // Fetch the configuration from the API
            const response = await axios.get(this.config.FOXINODES_API_DVPN_CONFIG, { timeout: 60000 });
            if (response.status === 200) {
                const data = response.data;
                // Check if the data is valid
                if (data && data.error === false) {
                    // Extract the configuration data
                    const chainId = data.chain_id || this.config.CHAIN_ID;
                    const rpcAddresses = data.rpc_addresses || this.config.RPC_ADDRESSES;
                    const gas = data.gas || this.config.GAS;
                    const gasAdjustment = data.gas_adjustment || this.config.GAS_ADJUSTMENT;
                    const gasPrice = data.gas_price || this.config.GAS_PRICE;
                    const datacenterGigabytePrices = data.datacenter.gigabyte_prices || this.config.DATACENTER_GIGABYTE_PRICES;
                    const datacenterHourlyPrices = data.datacenter.hourly_prices || this.config.DATACENTER_HOURLY_PRICES;
                    const residentialGigabytePrices = data.residential.gigabyte_prices || this.config.RESIDENTIAL_GIGABYTE_PRICES;
                    const residentialHourlyPrices = data.residential.hourly_prices || this.config.RESIDENTIAL_HOURLY_PRICES;
                    // Update the configuration
                    Object.assign(this.config, {
                        CHAIN_ID: chainId,
                        RPC_ADDRESSES: rpcAddresses,
                        GAS: gas,
                        GAS_ADJUSTMENT: gasAdjustment,
                        GAS_PRICE: gasPrice,
                        DATACENTER_GIGABYTE_PRICES: datacenterGigabytePrices,
                        DATACENTER_HOURLY_PRICES: datacenterHourlyPrices,
                        RESIDENTIAL_GIGABYTE_PRICES: residentialGigabytePrices,
                        RESIDENTIAL_HOURLY_PRICES: residentialHourlyPrices
                    });
                    // Log
                    Logger.info('Network configuration has been refreshed.');
                    return true;
                }
                else {
                    Logger.error('Invalid network configuration data.');
                }
            }
            else {
                Logger.error('Failed to fetch network configuration.');
            }
        }
        catch (err) {
            if (err instanceof Error)
                Logger.error(`Failed to refresh network configuration: ${err.message}`);
            else
                Logger.error(`Failed to refresh network configuration: ${String(err)}`);
        }
        return false;
    }
    /**
     * Get the default path for the Docker socket
     * @returns string
     */
    getDockerDefaultSocketPath() {
        const userInfo = os.userInfo();
        const userId = userInfo.uid;
        return `/run/user/${userId}/docker.sock`;
    }
    /**
     * Generate an authentication token
     * @returns string
     */
    generateAuthToken() {
        return uuidv4();
    }
    /**
     * Generate a JWT secret
     * @returns string
     */
    generateJwtSecret() {
        return uuidv4();
    }
}
// Exporter une instance unique de ConfigurationLoader
const configurationLoader = ConfigurationLoader.getInstance();
export default configurationLoader.getConfig();
export const getDockerDefaultSocketPath = () => configurationLoader.getDockerDefaultSocketPath();
export const getRemoteAddress = async () => configurationLoader.getRemoteAddress();
export const refreshNetworkConfiguration = async () => configurationLoader.refreshNetworkConfiguration();
export const resetConfiguration = () => configurationLoader.resetConfiguration();
export const setConfigurationValue = (key, value, persist = true) => configurationLoader.setConfigValue(key, value, persist);
