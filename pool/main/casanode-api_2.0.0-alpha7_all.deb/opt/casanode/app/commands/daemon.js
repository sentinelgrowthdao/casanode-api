import { Logger } from '../utils/logger.js';
import WebServer from '../utils/web.js';
import { loadingNodeInformations, loadingSystemInformations } from '../actions/startup.js';
/**
 * Daemon command
 * @returns void
 */
export const daemonCommand = async () => {
    Logger.info('Daemon process started.');
    try {
        // Load system information
        try {
            await loadingSystemInformations();
        }
        catch (error) {
            Logger.error('System bootstrap failed, continuing with degraded startup.', error);
        }
        // Load node information in the background so startup stays resilient
        void startNodeBootstrap();
        // Start the web server even if node bootstrap fails
        await startWebServer();
    }
    catch (error) {
        Logger.error('An unexpected error occurred in daemon process.', error);
    }
};
/**
 * Bootstrap node information without blocking web server startup
 * @returns Promise<void>
 */
const startNodeBootstrap = async () => {
    try {
        await loadingNodeInformations();
    }
    catch (error) {
        Logger.error('Node bootstrap failed, continuing with degraded startup.', error);
    }
};
/**
 * Start the web server
 * @returns void
 */
const startWebServer = async () => {
    try {
        Logger.info('Starting web server...');
        // Get the web server instance
        const webServer = WebServer.getInstance();
        // Initialize SSL and routes
        await webServer.init();
        // Start the web server
        webServer.start();
        Logger.info('Web server started successfully.');
    }
    catch (error) {
        Logger.error('Failed to start the web server.', error);
    }
};
