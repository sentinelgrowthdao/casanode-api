import { createRequire } from 'module';
import { Logger } from '../utils/logger.js';
import nodeManager from '../utils/node.js';
export class BandwidthSpeedCharacteristic {
    /**
     * Bleno instance
     * @type any
     */
    Bleno = undefined;
    /**
     * UUID of the characteristic
     * @type string
     */
    characteristicUuid = '';
    /**
     * Create a new instance of Characteristic
     */
    constructor(uuid) {
        const require = createRequire(import.meta.url);
        this.Bleno = require('bleno');
        this.characteristicUuid = uuid;
    }
    /**
     * Create a new instance of BandwidthSpeedCharacteristic
     */
    create() {
        if (this.Bleno === undefined)
            return null;
        return new this.Bleno.Characteristic({
            uuid: this.characteristicUuid,
            properties: ['read'],
            onReadRequest: this.onReadRequest.bind(this),
        });
    }
    /**
     * Called when the characteristic is read
     * @param offset number
     * @param callback (result: number, data: Buffer) => void
     * @returns void
     */
    onReadRequest(offset, callback) {
        let info = {
            d: -1,
            u: -1,
        };
        // Get the status of the node
        nodeManager.getNodeStatus().then((data) => {
            // Set the download and upload speed
            info.d = data?.bandwidth?.download ? data.bandwidth.download : -1;
            info.u = data?.bandwidth?.upload ? data.bandwidth.upload : -1;
            // Return the value to the subscriber
            callback(this.Bleno.Characteristic.RESULT_SUCCESS, Buffer.from(JSON.stringify(info)));
            return null;
        })
            .catch((error) => {
            Logger.error(`Error while reading the node status: ${error}`);
            callback(this.Bleno.Characteristic.RESULT_SUCCESS, Buffer.from(JSON.stringify(info)));
            return null;
        });
    }
}
