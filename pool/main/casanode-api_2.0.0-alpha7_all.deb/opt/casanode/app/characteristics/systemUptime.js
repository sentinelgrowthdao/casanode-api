import { createRequire } from 'module';
import nodeManager from '../utils/node.js';
export class SystemUptimeCharacteristic {
    /**
     * Bleno instance
     * @type any
     */
    Bleno = undefined;
    /**
     * UUID of the characteristic
     * @type string
     */
    characteristicUuid = '';
    /**
     * Create a new instance of Characteristic
     */
    constructor(uuid) {
        const require = createRequire(import.meta.url);
        this.Bleno = require('bleno');
        this.characteristicUuid = uuid;
    }
    /**
     * Create a new instance of SystemUptimeCharacteristic
     */
    create() {
        if (this.Bleno === undefined)
            return null;
        return new this.Bleno.Characteristic({
            uuid: this.characteristicUuid,
            properties: ['read'],
            onReadRequest: this.onReadRequest.bind(this),
        });
    }
    /**
     * Called when the characteristic is read
     * @param offset number
     * @param callback (result: number, data: Buffer) => void
     * @returns void
     */
    onReadRequest(offset, callback) {
        // Get the value from the certificate
        const info = nodeManager.getConfig().systemUptime;
        // Return the value to the subscriber
        callback(this.Bleno.Characteristic.RESULT_SUCCESS, Buffer.from(info.toString()));
    }
}
