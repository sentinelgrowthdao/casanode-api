import nodeManager from '../utils/node.js';
import { getNodeStatus } from '../utils/node.js';
import { certificateInfo } from '../utils/certificate.js';
/**
 * GET /api/v1/status
 * Returns the node status
 * @param req Request
 * @param res Response
 * @returns void
 */
export async function getStatus(req, res) {
    // Get the status of the node
    const dataStatus = await getNodeStatus();
    // Get the certificate information
    const certInfo = certificateInfo();
    // Get node configuration
    const nodeConfig = nodeManager.getConfig();
    // Return the status of the node
    res.json({
        version: nodeConfig.casanodeVersion || null,
        uptime: nodeConfig.systemUptime || null,
        nodeLocation: nodeConfig.nodeLocation || null,
        systemArch: nodeConfig.systemArch || null,
        systemKernel: nodeConfig.systemKernel || null,
        systemOs: nodeConfig.systemOs || null,
        status: dataStatus,
        certificate: certInfo,
    });
}
