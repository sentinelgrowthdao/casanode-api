import { checkImageAvailability, containerExists, containerRunning, } from '../utils/docker.js';
import { isNodeConfigFileAvailable, isCertificateKeyAvailable, isWalletAvailable, } from '../utils/node.js';
;
export const checkInstallation = async () => {
    // Return the installation check
    return {
        image: await checkImageAvailability(),
        containerExists: await containerExists(),
        containerRunning: await containerRunning(),
        nodeConfig: isNodeConfigFileAvailable(),
        certificateKey: isCertificateKeyAvailable(),
        wallet: await isWalletAvailable(),
    };
};
